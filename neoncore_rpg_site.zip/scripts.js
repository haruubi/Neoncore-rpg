
const personagens = [
    { nome: "Nyx", imagem: "img/nyx.jpg", descricao: "Especialista em infiltração e hacking." },
    { nome: "Vektor", imagem: "img/vektor.jpg", descricao: "Mercenário modificado com implantes de combate." },
    { nome: "Echo", imagem: "img/echo.jpg", descricao: "Espiã com habilidades de camuflagem e agilidade." },
    { nome: "Draven", imagem: "img/draven.jpg", descricao: "Engenheiro e estrategista com braço mecânico." },
    { nome: "Sable", imagem: "img/sable.jpg", descricao: "Lutadora de rua com força aprimorada." },
    { nome: "Kairo", imagem: "img/kairo.jpg", descricao: "Líder rebelde com habilidades táticas." },
];

const characterList = document.getElementById("character-list");
const selectionList = document.getElementById("selection");
let selected = [];

function atualizarSelecionados() {
    selectionList.innerHTML = "";
    selected.forEach(p => {
        const li = document.createElement("li");
        li.textContent = p.nome;
        selectionList.appendChild(li);
    });
}

personagens.forEach(p => {
    const div = document.createElement("div");
    div.className = "character-card";
    div.innerHTML = \`
        <img src="\${p.imagem}" alt="\${p.nome}" />
        <h3>\${p.nome}</h3>
        <p>\${p.descricao}</p>
        <button onclick="selecionarPersonagem('\${p.nome}')">Escolher</button>
    \`;
    characterList.appendChild(div);
});

function selecionarPersonagem(nome) {
    if (selected.length >= 5) return alert("Você só pode escolher até 5 personagens!");
    const personagem = personagens.find(p => p.nome === nome);
    if (!selected.includes(personagem)) {
        selected.push(personagem);
        atualizarSelecionados();
    }
}
